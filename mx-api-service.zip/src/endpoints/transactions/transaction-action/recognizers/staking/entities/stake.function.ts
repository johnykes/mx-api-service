export enum StakeFunction {
  delegate = 'delegate',
  stake = 'stake',
  unDelegate = 'unDelegate',
  claimRewards = 'claimRewards',
  reDelegateRewards = 'reDelegateRewards',
  withdraw = 'withdraw',
}
