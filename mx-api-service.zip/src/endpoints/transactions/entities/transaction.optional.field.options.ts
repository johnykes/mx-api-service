export enum TransactionOptionalFieldOption {
  results = 'results',
  logs = 'logs',
  operations = 'operations',
  receipt = 'receipt',
}
