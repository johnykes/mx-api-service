export enum BatchTransactionStatus {
  pending = 'pending',
  invalid = 'invalid',
  dropped = 'dropped',
  success = 'success',
}
