import { TransactionDetails } from "./transaction.details";

export class TransactionBatchSimplified {
  id: string = '';

  transactions: TransactionDetails[][] = [];
}
