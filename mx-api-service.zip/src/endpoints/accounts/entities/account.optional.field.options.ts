export enum AccountOptionalFieldOption {
  scrCount = "scrCount",
  txCount = "txCount",
}
