export enum AuctionStatus {
  running = 'running',
  claimable = 'claimable',
  ended = 'ended',
  closed = 'closed',
  unknown = 'unknown',
}
