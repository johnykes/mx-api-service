export enum SortCollections {
  timestamp = 'timestamp',
  verifiedAndHolderCount = 'verifiedAndHolderCount',
}
