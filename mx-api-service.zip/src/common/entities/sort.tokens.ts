export enum SortTokens {
    accounts = 'accounts',
    transactions = 'transactions',
    price = 'price',
    marketCap = 'marketCap',
}
