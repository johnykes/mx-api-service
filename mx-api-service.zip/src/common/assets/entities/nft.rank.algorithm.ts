export enum NftRankAlgorithm {
  trait = 'trait',
  statistical = 'statistical',
  openRarity = 'openRarity',
  jaccardDistances = 'jaccardDistances',
  custom = 'custom',
}
