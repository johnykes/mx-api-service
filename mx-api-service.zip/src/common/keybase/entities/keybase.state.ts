export class KeybaseState {
  identity: string | undefined = '';
  confirmed: boolean = false;
}
