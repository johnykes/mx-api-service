export class NotifierEvent {
  address: string = '';
  identifier: string = '';
  topics: string[] = [];
}
